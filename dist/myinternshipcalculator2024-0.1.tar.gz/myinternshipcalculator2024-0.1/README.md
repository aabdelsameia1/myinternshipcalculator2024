# myinternshipcalculator2024

A simple internship hours calculator.

## Installation

```bash
pip install myinternshipcalculator2024
```
